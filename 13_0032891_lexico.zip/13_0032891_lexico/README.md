# Lexycal Analyser

The how-to run this program is described in "analisador-lexico-tradutores.pdf".
